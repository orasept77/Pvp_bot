def close_connection(connection):
    connection.close()