# BOT Mishy "1931351582:AAG-JYJQeEDheG1pDjnbngLtLF9STyYT7SI"
# ID Mishy 573332887
# Bot Maxona "1978069005:AAG4_D989tb12LvZ1ol7zL0aOIuOGF8NKFk"
# ID Maxona 462567885

BOT_TOKEN = "1978069005:AAG4_D989tb12LvZ1ol7zL0aOIuOGF8NKFk"  # Забираем значение типа str
ADMINS = [462567885]  # Тут у нас будет список из админов
IP = "localhost"  # Тоже str, но для айпи адреса хоста
